package es.indra.utils;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ManejoExcepcionesGlobales {
	
	// http://localhost:8002/crear/256677/cantidad/25
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> errorNoExisteId(RuntimeException ex){
		return new ResponseEntity<String>("ID producto no existe", HttpStatus.NOT_FOUND);
	}

}
