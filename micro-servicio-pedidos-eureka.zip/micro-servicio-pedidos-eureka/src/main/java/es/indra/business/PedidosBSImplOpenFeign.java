package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.clients.ProductosClienteFeign;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
@Primary   // Le doy preferencia para DI
public class PedidosBSImplOpenFeign implements IPedidosBS{
	
	@Autowired   // solo se puede inyectar un bean en otro bean
	private ProductosClienteFeign clienteFeign;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// Buscar el producto con ese id
		Producto producto = clienteFeign.buscar(id);
		
		// Crear el pedido
		Pedido pedido = new Pedido(producto, cantidad);
		
		// Retornar el pedido
		return pedido;
	}

}
