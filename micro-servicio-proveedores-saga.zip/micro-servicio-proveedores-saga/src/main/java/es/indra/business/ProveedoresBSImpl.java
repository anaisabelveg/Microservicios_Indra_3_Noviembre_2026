package es.indra.business;

import org.springframework.stereotype.Service;

@Service
public class ProveedoresBSImpl implements IProveedoresBS{

	@Override
	public String crearProveedor(String nombre) {
		
		if ("Pepe".equals(nombre))
			throw new RuntimeException("Transaccion cancelada por el nombre Pepe");
		
		return "Proveedor " + nombre + " creado con exito";
	}

}
