package es.indra.utils;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import feign.FeignException;

@RestControllerAdvice
public class ManejoExcepcionesGlobales {
	
	// Igual que podemos tener un bloque try con multiples catch
	// Aqui podemos tebner varios metodos que cada uno capture un tipo de excepcion
	
	// http://localhost:8002/crear/256677/cantidad/25
	//	@ExceptionHandler(RuntimeException.class)
    //		public ResponseEntity<String> errorNoExisteId(RuntimeException ex){
	//		return new ResponseEntity<String>("ID producto no existe", HttpStatus.NOT_FOUND);
    //	}
	
	// http://localhost:8002/crear/256677/cantidad/25
	@ExceptionHandler(FeignException.class)
	public ResponseEntity<String> errorValidacion(FeignException ex){
		return new ResponseEntity<String>("ID producto fuera de rango 1-6", HttpStatus.NOT_FOUND);
	}
	
	// http://localhost:8002/crear/aaaaaa/cantidad/25
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> errorIdTexto(Exception ex){
		return new ResponseEntity<String>("ID producto debe ser numerico", HttpStatus.BAD_REQUEST);
	}

}
