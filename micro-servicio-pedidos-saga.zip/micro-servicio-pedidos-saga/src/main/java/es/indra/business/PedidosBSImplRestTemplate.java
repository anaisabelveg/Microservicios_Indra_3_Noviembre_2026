package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
public class PedidosBSImplRestTemplate implements IPedidosBS{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// Buscar el producto con ese id
		Producto producto = restTemplate.getForObject(
				"http://servicio-productos/buscar/{codigo}", Producto.class, id);
		
		// Crear el pedido
		Pedido pedido = new Pedido(producto, cantidad);
		
		// Retornar el pedido
		return pedido;
	}

	@Override
	public String pruebaTransaccion(String descripcion, double precio, String nombreProveedor) {
		String mensaje = "";
		Producto producto = null;
		
		try {
			// Dar de alta el nuevo producto
			producto = restTemplate.postForObject("http://servicio-productos/nuevo/descripcion/{descripcion}/precio/{precio}", 
					null, Producto.class, descripcion, precio);
						
			// Dar de alta el proveedor
			restTemplate.postForObject("http://servicio-proveedores/alta/{nombre}", 
					null, String.class, nombreProveedor);
			
			mensaje = "Todo ha ido bien, transacciones completadas";
			
		} catch (Exception e) {
			// Deshacer la transaccion, eliminar el producto creado
			restTemplate.delete("http://servicio-productos/eliminar/{id}", producto.getId());
			mensaje = "Transaccion deshecha";
		}
		
		return mensaje;
	}

}
