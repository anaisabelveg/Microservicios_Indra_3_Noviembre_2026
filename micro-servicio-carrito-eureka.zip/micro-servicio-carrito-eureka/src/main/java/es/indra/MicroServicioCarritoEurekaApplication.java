package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

import es.indra.persistence.CarritosDAO;

@SpringBootApplication
@EnableEurekaClient
@EnableFeignClients
public class MicroServicioCarritoEurekaApplication implements CommandLineRunner{
	
	@Autowired
	private CarritosDAO dao;

	// El metodo main en Spring Boot esta dedicado exclusivamente a
	// levantar el contexto de Spring
	// por lo tanto, aqui no se escribe nada de codigo
	public static void main(String[] args) {
		SpringApplication.run(MicroServicioCarritoEurekaApplication.class, args);
	}

	// Este metodo se ejecuta de forma automatica a continuacion del metodo main
	// Es una garantia saber que ya tenemos el bean dao inyectado
	@Override
	public void run(String... args) throws Exception {
		
		// Limpiar la tabla de carritos
		//dao.deleteAll();
		
	}

}
