package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

// Escanea todos los paquetes que comienzan por es.indra y busca las clases anotadas
// para crear los beans y meterlos en el contenedor
@SpringBootApplication
@EnableEurekaClient
public class MicroServicioProductosApplication {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// crear el contenedor con todos los beans que se han detectado
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

}
