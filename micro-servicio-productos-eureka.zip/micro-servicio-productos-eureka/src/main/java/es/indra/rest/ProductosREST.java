package es.indra.rest;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProductosBS;
import es.indra.entities.Producto;

@RestController
public class ProductosREST {
	
	@Autowired  // Para inyectar beans
	private IProductosBS bs;
	
	@Value("${server.port}")  // Para inyectar valores (tipos primitivos y String)
	private Integer port;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return bs.consultarTodos()
				.stream()
				.map(prod -> {
					prod.setPort(port);
					return prod;
				})
				.collect(Collectors.toList());
	}
	
	// http://localhost:8001/buscar/3
	@GetMapping("/buscar/{codigo}")
	public Producto buscar(@PathVariable(name = "codigo") Long id) {
		Producto producto = bs.buscarProducto(id);
		
		// Si no encontramos el producto lanzamos una excepcion
		if (producto.getDescripcion() == null)
			throw new RuntimeException("Ese producto no existe");
		
		producto.setPort(port);
		return producto;
	}

}
